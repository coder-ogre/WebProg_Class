<?php
/*
 This is a multiline comment
 */
    $data = "Hello World";
    $data = 5;
    echo "<html> <body>Test".$data."</body> </html>";
?>
